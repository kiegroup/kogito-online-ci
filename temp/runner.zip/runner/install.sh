#!/bin/bash
./stop.sh
java  -jar jitdmn-1.0.0-SNAPSHOT-runner.jar  &> output.log &