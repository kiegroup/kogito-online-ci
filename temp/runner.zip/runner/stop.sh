#!/bin/bash
pid=$(lsof -ti tcp:8080)
if [[ $pid ]]; then
  kill -9 $pid
fi